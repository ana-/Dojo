#include<stdio.h>


void escreve_unidade(int valor) {
	switch (valor) {
	case 1:
		printf("UM ");
		break;
	case 2:
		printf("DOIS ");
		break;
	case 3:
		printf("TRES ");
		break;
	case 4:
		printf("QUATRO ");
		break;
	case 5:
		printf("CINCO ");
		break;
	case 6:
		printf("SEIS ");
		break;
	case 7:
		printf("SETE ");
		break;
	case 8:
		printf("OITO ");
		break;
	case 9:
		printf("NOVE ");
		break;
	}
}

void escreve_dezena(int valor_dez, int valor_uni) {
	switch (valor_dez) {
	case 1:
		switch (valor_uni) {
		case 0:
			printf("DEZ ");
			break;
		case 1:
			printf("ONZE ");
			break;
		case 2:
			printf("DOZE ");
			break;
		case 3:
			printf("TREZE ");
			break;
		case 4:
			printf("QUATORZE ");
			break;
		case 5:
			printf("QUINZE ");
			break;
		case 6:
			printf("DEZESSEIS ");
			break;
		case 7:
			printf("DEZESSETE ");
			break;
		case 8:
			printf("DEZOITO ");
			break;
		case 9:
			printf("DEZENOVE ");
			break;
		}
		break;
	case 2:
		printf("VINTE ");
		break;
	case 3:
		printf("TRINTA ");
		break;
	case 4:
		printf("QUARENTA ");
		break;
	case 5:
		printf("CINQUENTA ");
		break;
	case 6:
		printf("SESSENTA ");
		break;
	case 7:
		printf("SETENTA ");
		break;
	case 8:
		printf("OITENTA ");
		break;
	case 9:
		printf("NOVENTA ");
		break;
	}

	if (valor_uni != 0 && valor_dez != 1) {
		printf("E ");
		escreve_unidade(valor_uni);
	}
}

void escreve_centena(int valor_cen, int valor_dez, int valor_uni) {
	switch (valor_cen) {
	case 1:
		if (valor_dez != 0 || valor_uni != 0)
			printf("CENTO ");
		else
			printf("CEM");
		break;
	case 2:
		printf("DUZENTOS ");
		break;
	case 3:
		printf("TREZENTOS ");
		break;
	case 4:
		printf("QUATROCENTOS ");
		break;
	case 5:
		printf("QUINHENTOS ");
		break;
	case 6:
		printf("SEISCENTOS ");
		break;
	case 7:
		printf("SETECENTOS ");
		break;
	case 8:
		printf("OITOCENTOS ");
		break;
	case 9:
		printf("NOVECENTOS ");
		break;
	}

	if (valor_dez != 0) {
		if(valor_cen != 0)
		printf("E ");
		escreve_dezena(valor_dez, valor_uni);
	}
	else if (valor_uni != 0) {
		if (valor_cen != 0)
		printf("E ");
		escreve_unidade(valor_uni);
	}
}

int main() {
	int valor, U=0, D=0, C=0, UM=0, DM=0, CM=0;

	for (valor = 10000; valor < 100000; valor++) {

		/*printf("Valor do cheque:");
		scanf_s("%d", &valor);*/

		U = (valor / 1) % 10;
		D = (valor / 10) % 10;
		C = (valor / 100) % 10;

		UM = (valor / 1000) % 10;
		DM = (valor / 10000) % 10;
		CM = valor / 100000;

		
			escreve_centena(CM, DM, UM);
			printf("MIL ");
			escreve_centena(C, D, U);
		

		printf("\n");

//	printf("%d %d %d %d %d %d\n", CM, DM, UM, C, D, U);
	}
	return 0;
}
